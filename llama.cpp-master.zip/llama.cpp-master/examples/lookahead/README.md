# llama.cpp/examples/lookahead

Demonstration of lookahead decoding technique:

https://lmsys.org/blog/2023-11-21-lookahead-decoding/

More info: https://github.com/ggml-org/llama.cpp/pull/4207
